#%% Define the number of students and the weight gain per student
num_students = 59
weight_gain_per_student = 100  # in grams

# Calculate the total weight gain for all students
total_weight_gain = num_students * weight_gain_per_student

# Calculate the total weight of the remaining students
total_weight = total_weight_gain

# Calculate the average weight of the remaining students
average_weight = total_weight / num_students

print("The average weight of the remaining students is approximately", average_weight, "grams.")
# %%
