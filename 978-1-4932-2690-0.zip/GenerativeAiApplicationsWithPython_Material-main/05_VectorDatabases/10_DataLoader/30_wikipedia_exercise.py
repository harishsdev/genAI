#%% (1) Packages

#%% Articles to load
articles = [
    {'title': 'Artificial Intelligence',
     'query': 'https://en.wikipedia.org/wiki/Artificial_intelligence'},
    {'title': 'Artificial General Intelligence',
     'query': 'https://en.wikipedia.org/wiki/Artificial_general_intelligence'},
    {'title': 'Superintelligence',
        'url': 'https://en.wikipedia.org/wiki/Superintelligence'},
]

# %% (2) Load articles

